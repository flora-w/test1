


export const FORM_DATA='form_data/FORM_DATA';
export const GET_ALL_FORM='get_all_form/GET_ALL_FORM';
export const GET_ALL_DEPT='get_all_dept/GET_ALL_DEPT';
export const GET_DEPT_AGENT='get_dept_agent/GET_DEPT_AGENT';
export const SUBMIT_DATA='submit_data/SUBMIT_DATA';