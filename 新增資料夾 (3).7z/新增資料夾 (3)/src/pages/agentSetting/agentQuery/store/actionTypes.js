export const INPUT_DATA='input_data/INPUT_DATA';
export const DATA_SEARCH ='data_search/DATA_SEARCH';