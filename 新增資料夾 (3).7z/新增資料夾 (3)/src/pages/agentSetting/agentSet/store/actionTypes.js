export const FINANCE_DATA='finance_data/FINANCE_DATA';

export const PERSONALAGENT_DATA='personalagent_data/PERSONALAGENT_DATA';
export const GET_DEPT='get_dept/GET_DEPT'; 
export const GET_ALL_DEPT='get_all_dept/GET_ALL_DEPT';
export const GET_DEPT_AGENT='get_dept_agent/GET_DEPT_AGENT';
export const SUBMIT_DATA='submit_data/SUBMIT_DATA';