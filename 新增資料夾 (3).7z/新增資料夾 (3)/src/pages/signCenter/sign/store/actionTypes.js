export const SIGN_PAGE_DATA='SIGN_PAGE_DATA';
export const CURR_PAGE='CURR_PAGE';