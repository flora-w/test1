import React,{Fragment, Component } from 'react';
import {Popconfirm, Form,Card, Table, Input, Button } from 'antd';
import {connect} from 'react-redux';
import {actionCreators} from './store';
import { Record } from 'immutable';
import { Link } from 'react-router-dom';



class SpecialNameMaintain extends Component {

  componentDidMount(){
    this.props.getPageData();
  }

  render(){
    
    const columns =[
      {title:'工號',dataIndex:'userid',align:'center'},
      {title:'姓名',dataIndex:'username',align:'center'},
      // {title:'編輯',dataIndex:'edit',align:'center'},
      {title:'刪除',dataIndex:'delete',align:'center',
       render:(record,index)=>
       <Popconfirm
       title='你確認要刪除嗎？'
       onConfirm={()=>deleteFormData(record,index)}
       okText='是'
       onCancel='否'
       >
       <a>刪除</a>
       </Popconfirm>
      },
    ]

    const {deleteFormData,data,submit,form,form:{getFieldDecorator,validateFields}}=this.props;
    return(
        <Fragment>
          <Card
        title='特殊人员姓名维护'
        bordered={false}
        loading={false}
        headStyle={{color: '#666'}}
        style={{margin: 5}}
      >
        <span>工號：&emsp;
            {
                getFieldDecorator('useid')
                (<Input style={{width:200}}/>)
            }
            <span>&emsp;&emsp;</span>
            <span>姓名：&emsp;
                {
                     getFieldDecorator('usename')
                     (<Input style={{width:200}}/>)
                }
            </span>
            <span>&emsp;&emsp;</span>
            <Button
            onClick={()=>submit(form)}
            >新增</Button>
        </span>
        <Table
        columns={columns}
        dataSource={data}
        />
    </Card>
    </Fragment>
    )
  }
}





const mapStateToProps=(state)=>{
  const {data}=state.SpecialNameReducer.SpecialNameMaintainReducer;
  return {data}
}
const mapDispatchToProps=(dispatch)=>{
  return{
    getPageData(){
      dispatch(actionCreators.getPageData())
    },
    submit(form){
        form.validateFields((err,values)=>{
            if(!err){
                console.log(values)
                dispatch(actionCreators.submit(values))
            }
        })
    },
    deleteFormData(record,index){
      dispatch(actionCreators.deleteFamilyInfo(record,index))
    },
  }
}

export default Form.create()(connect(mapStateToProps,mapDispatchToProps)(SpecialNameMaintain));

