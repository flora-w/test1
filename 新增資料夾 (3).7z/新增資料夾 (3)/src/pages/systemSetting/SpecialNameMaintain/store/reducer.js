import * as actionTypes from './actionTypes';

const defaultState={
   data:[],
}
const submitdata=(newState,action)=>{
   newState.data=action.data;
   return newState;
}
const getData2=(newState,action)=>{
   newState.data=action.data;
   return newState
}
export default (state=defaultState,action)=>{
   const newState=JSON.parse(JSON.stringify(state));
   switch(action.type){
      case actionTypes.SUBMIT_DATA:
           return submitdata(newState,action);
       case actionTypes.GET_DATA:
           return getData2(newState,action);
       default:
           return newState;
   }
}
