export const SUBMIT_DATA='submit_data/SUBMIT_DATA'
export const GET_DATA='get_data/GET_DATA'