import axios from 'axios';
import * as actionTypes from './actionTypes';
import {DELETE_CONTACTS } from "../../../../config/api";
import { removeFileItem } from 'antd/lib/upload/utils';
import { compose } from 'redux';
import {message} from 'antd';

export const submit1=(data)=>{
    return{
        type:actionTypes.SUBMIT_DATA,
        data
    }
}

export const getPageDatad =(data)=>{
    return{
        type:actionTypes.GET_DATA,
        data
    }
}
export const submit=(values)=>{

    return(dispatch)=>{
        axios.get({url:DELETE_CONTACTS},values).then((res)=>{
            if(res.data.code==1){
                return submit1(res.data.data)
            }else{
                console.log('err')
            }
        }).catch((err)=>{
            console.log('err')
        })
    }

}

export const getPageData =()=>{
    return(dispatch)=>{
        axios.get('./api/SpecialPerson.json').then((res)=>{
            if(res.data.code==1)  {
                 dispatch(getPageDatad(res.data.data))
            }else{
                console.log('err')
            }
        }).catch((err)=>{
            console.log('err');
        })
    }
}
export const deleteFamilyInfo=(record,index)=>{
    let data={
      record,index
    }
    return(dispatch)=>{
      axios.post({url:DELETE_CONTACTS,data}).then((res)=>{
        if(res.data.code===1){
          message.success('删除成功');
          dispatch(getPageData())
        }else{
          message.warning(res.message);
        }
      })
      .catch((err)=>{
        console.log('删除失败',err)
      })
    }
  }