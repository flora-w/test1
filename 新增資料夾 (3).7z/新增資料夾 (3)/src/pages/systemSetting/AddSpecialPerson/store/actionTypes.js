export const SELECT_TYPE='select_type/SELECT_TYPE';    
export const IS_PUBLIC='is_public/IS_PUBLIC';
export const SAVEUPLOAD_FILE ='budget-allowance/SAVEUPLOAD_FILE';
export const SHOW_BTN = 'budget-allowance/SHOW_BTN';
export const GET_PAGE_DATA_SECOND ='admaintain/GET_PAGE_DATA_SECOND';