export const CHANGE_MODE ='change_mode/CHANGE_MODE';  
export const GET_DATA ='get_data/GET_DATA';