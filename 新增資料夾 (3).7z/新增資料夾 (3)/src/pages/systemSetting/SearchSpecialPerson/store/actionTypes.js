export const ON_SELECT='on_select/ON_SELECT';
export const ON_INPUT='on_input/ON_INPUT';
export const GET_DATA='get_data/GET_DATA';