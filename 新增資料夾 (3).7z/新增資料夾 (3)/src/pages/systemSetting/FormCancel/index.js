import React, {Component, Fragment , useState, useEffect } from 'react';
import { Card, Table, Button, Col, Form, Input, Row ,Tag} from 'antd';
import { connect } from 'react-redux';
import { actionCreators } from '../FormCancel/store';



class FormCancel extends Component{

  render(){
    const _columns = [
      {title: '表單名稱', dataIndex: 'formname', align: 'center'},
      {title: '開始時間', dataIndex: 'startDate', align: 'center'},
      {title: '結束時間', dataIndex: 'endDate', align: 'center'},
      {title: '代理人', dataIndex: 'agent', align: 'center'},
      {title: '狀態', dataIndex: 'condition', align: 'center', render: (text,record) => <Tag color='blue'>{record.condition}</Tag>},
      {title: 'Cancel' ,dataIndex: 'cancel', align: 'center', render: (text,record) => <Tag color='#f50'>Cancel</Tag>}
    ];
    const {form,form:{getFieldDecorator,validateFields},submit,data}=this.props;
    return(
      <Fragment>
      <Card
      title='表单取消'
      headStyle={{color: '#666'}}
      bordered={false}
      style={{margin: 5}}
    >
    <span>單號：&emsp;
      {
        getFieldDecorator('sequenceid')
        (<Input style={{width:200}}/>)
      }
      <span>&emsp;&emsp;</span>
      <Button
       onClick={()=>submit(form)}
      >
        查詢
      </Button>
    </span>
          
  </Card>
  <Card
      title='查询结果'
      bordered={false}
      headStyle={{color: '#666'}}
      style={{margin: 5}}
    >
    <Table 
        columns={_columns}
        // dataSource={data}
      />
  </Card>
  </Fragment>
    )
  }

}

const mapStateToProps=(state)=>{
  const {data}=state.FormCanceledReducer.FormCancelReducer;
  return {data}
}
const mapDispatchToProps=(dispatch)=>{
  return{
    submit(form){
      form.validateFields((err,values)=>{
       if(!err){
         console.log(values)
         dispatch(actionCreators.submite(values))
       }else{
        
       }
      })

    }
  }
}
export default Form.create()(connect(mapStateToProps,mapDispatchToProps)(FormCancel));
