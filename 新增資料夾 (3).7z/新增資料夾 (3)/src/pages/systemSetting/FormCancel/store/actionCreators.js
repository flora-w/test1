import axios from 'axios';
import * as actionTypes from './actionTypes';
import {DELETE_CONTACTS } from "../../../../config/api";
import { removeFileItem } from 'antd/lib/upload/utils';
import { compose } from 'redux';
import {message} from 'antd';


export const submit1=(data)=>{
    return{
        type:actionTypes.SUBMIT_DATA,
        data
    }
}

export const submite=(values)=>{
    return(dispatch)=>{
        axios.get({url:DELETE_CONTACTS},values).then((res)=>{
            if(res.data.code==1){
                return submit1(res.data.data)
            }else{
                console.log('err')
            }
        }).catch((err)=>{
            console.log('err')
        })
    }
}