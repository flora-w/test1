export const SHOW_MODAL = 'adminMaintain/SHOW_MODAL';
export const HIDE_MODAL = 'adminMaintain/HIDE_MODAL';
export const MODIFY_CANCEL = 'modify_cancel/MODIFY_CANCEL';
export const MODIFY_MODAL = 'modify_modal/MODIFY_MODAL';
export const GET_NAME = 'adminMaintain/GET_NAME';
export const ADD_DATA = 'personInfoMaintain/ADD_DATA';
export const PAGE_DATA='page_data/PAGE_DATA'
