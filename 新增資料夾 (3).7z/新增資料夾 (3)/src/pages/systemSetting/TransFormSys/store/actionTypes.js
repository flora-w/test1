export const SUBMIT_FORM='submit_form/SUBMIT_FORM';
export const GET_TYPE='get_type/GET_TYPE';
export const GET_ID='get_id/GET_ID';