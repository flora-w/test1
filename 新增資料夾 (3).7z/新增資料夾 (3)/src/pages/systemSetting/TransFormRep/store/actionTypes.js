
export const GET_DATA ='get_data/GET_DATA';
export const GET_RANK ='get_rank/GET_RANK';