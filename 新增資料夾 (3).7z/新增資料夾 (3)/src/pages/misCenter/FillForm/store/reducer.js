import * as actionTypes from './actionTypes';

const defaultState={
    name:'',
    userid:'',
}

const get_details =(newState,action)=>{
    newState.name=sessionStorage.getItem('user');
    newState.userid=sessionStorage.getItem('userId');
    return newState;
}

export default(state=defaultState,action)=>{
    const newState=JSON.parse(JSON.stringify(state));
    switch (action.type){
        case actionTypes.GET_DETAIL:
            return get_details(newState,action)
        default:
            return newState;
    }
}