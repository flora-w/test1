import axios from 'axios';
import  * as actionTypes from './actionTypes';
import {
PUBLISHING_SEARCH_PAGE_INFO } from "../../../../config/api";


export const getPersonDetail =()=>{
    return{
        type:actionTypes.GET_DETAIL
    }
}