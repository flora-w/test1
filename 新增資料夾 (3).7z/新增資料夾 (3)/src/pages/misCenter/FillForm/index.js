import React ,{Fragment,Component} from 'react';
import {Table,message,DatePicker,Radio,Form, Input, Button} from 'antd';
import RadioGroup from 'antd/lib/radio/group';
import TextArea from 'antd/lib/input/TextArea';
import { Link } from 'react-router-dom';
import {MisCenter2 as a } from '../../../config/navConfig';
import LeftNav from '../../../components/leftNav';
import FillFormArea from '../../../components/FillFormArea';
import CommitForm from './components/CommitForm';
class FillForm extends Component{


    render(){
        const columns = [
            {title: '序號', dataIndex: 'uniqueid', align: 'center'},
            {title: 'site', dataIndex: 'site', align: 'center'},
            {title: '系統/function', dataIndex: 'function', align: 'center'},
            {title: 'pic', dataIndex: 'pic', align: 'center'},
            {title: 'ext', dataIndex: 'ext', align: 'center'},
          ];
        
        return(
          <Fragment>

          <LeftNav navConfig={a}/>
           <FillFormArea 
          other={<CommitForm/>}
          />        
          </Fragment>
        )
    }
}

export default Form.create()(FillForm);


