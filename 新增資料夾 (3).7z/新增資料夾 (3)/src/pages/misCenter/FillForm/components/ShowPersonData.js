import React,{Component} from 'react';
import  {Table,Radio,Select,Input,DatePicker, Modal, Button, Form } from 'antd';

class ShowPersonData extends Component{

    render(){

        const columns =[
            {title:'服务类型',dataIndex:'servicetype',align:'center'},
            {title:'申请人工号',dataIndex:'applyid',align:'center'},
            {title:'申请人姓名',dataIndex:'applyname',align:'center'},
            {title:'部门代码',dataIndex:'deptcode',align:'center'},
            {title:'日期',dataIndex:'date',align:'center'},
            {title:'Enname',dataIndex:'enname',align:'center'},
            {title:'DeptPlant',dataIndex:'deptplant',align:'center'},
            {title:'Action',dataIndex:'action',align:'center'},
        ]

        return(
            <Table
            columns={columns}
            
            />
        )
    }
}

export  default Form.create()(ShowPersonData)