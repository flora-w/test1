import React,{Component} from 'react';
import  {Radio,Select,Input,DatePicker, Modal, Button, Form } from 'antd';
const { Option } = Select;

class AddPerson extends Component {

    onChange2 = e => {
        console.log(e.target.value);
        this.setState({
          value: e.target.value,
        });
      };

    state = { visible: false };

    showModal = () => {
      this.setState({
        visible: true,
      });
    };
  
    handleOk = e => {
      console.log(e);
      this.setState({
        visible: false,
      });
    };
  
    handleCancel = e => {
      console.log(e);
      this.setState({
        visible: false,
      });
    };

    render(){
        return(
        <div>
        <Button type="primary" onClick={this.showModal}
        style={{float:'right',marginRight:'600px'}}
        >
        新增申请人
        </Button>
        <Modal
          title="New Applier Addition"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          style={{width:4000}}
        >
         <div>申请人工号：&emsp;
             <Input style={{width:150}}/>&emsp;
             申请人工号：kkk&emsp; 
         </div>
         <div>&emsp;</div>
         <div>
             部门代码：DML111&emsp;
             英文名：ada&emsp;
            分机号：9090&emsp;
         </div>
         <div>&emsp;</div>
         <div>
           开始时间：&emsp;<DatePicker style={{width:120}}/>&emsp;
           结束时间：&emsp;<DatePicker style={{width:120}}/>
         </div>
         <div>&emsp;</div>
         <div>plant:&emsp;
         <Radio.Group onChange={this.onChange2}>
        <Radio value='plant1'>plant1</Radio>
        <Radio value='plant2'>plant2</Radio>
        <Radio value='plant3'>plant3</Radio>
        <Radio value='plant4'>plant4</Radio>
        <Radio value='plant5'>plant5</Radio>
        <Radio value='plant6'>plant6</Radio>
         </Radio.Group>
         </div>
        </Modal>
      </div>
        )

    }
}
export  default Form.create()(AddPerson)