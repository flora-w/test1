import React ,{Fragment,Component} from 'react';
import RadioGroup from 'antd/lib/radio/group';
import TextArea from 'antd/lib/input/TextArea';
import { Link } from 'react-router-dom';
 import {Radio ,Menu,Card ,Dropdown,Select,Form,message ,Button } from 'antd';
 import {connect } from 'react-redux';
 import {actionCreators} from '../store'
import AddPerson from './AddPerson';
import ShowPersonData from './ShowPersonData';
import UploadFile from './UploadFile';
import { stat } from 'fs';


 const { Option } = Select;

class CommitForm extends Component{

     onChange1(value) {
        console.log(`selected ${value}`);
      }
      
       onBlur() {
        // console.log('blur');
      }
      
       onFocus() {
        // console.log('focus');
      }
      
       onSearch(val) {
        // console.log('search:', val);
      }  
      onChange2 = e => {
        console.log(e.target.value);
        this.setState({
          value: e.target.value,
        });
      };
      showdata(e){
          console.log(e.target.value)
      }


      componentDidMount(){
            this.props.getPersonDetail()
      }
    render(){

    
      const {userid,name}=this.props;
        return(
         <Fragment>
         <Card 
         title='资讯服务申请单'
         bordered={false}
         headStyle={{color: '#666'}}
         style={{margin: 5}}
         >
         <div>填单人姓名：&emsp;{name}&emsp;&emsp;填单人工号:&emsp;{userid}&emsp;&emsp;填单人座机：&emsp;8080
         </div>
         <div>&emsp;</div>
         <div>申请对象:&emsp; 
            <Select
                showSearch
                style={{ width: 200 }}
                placeholder="Select "
                optionFilterProp="children"
                onChange={this.onChange1}
                onFocus={this.onFocus}
                onBlur={this.onBlur}
                onSearch={this.onSearch}
                filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
            >
                <Option value="WKS">昆山厂区</Option>
                <Option value="WCD">成都厂区</Option>
                <Option value="WCQ">重庆厂区</Option>
                <Option value="WTZ">泰州厂区</Option>
                <Option value="WZS">中山厂区</Option>
            </Select>
         </div>
         <div>&emsp;</div>
         <div>服务类型：&emsp;
         <Radio.Group onChange={this.onChange2}>
        <Radio value={1}>企业应用系统(Enterprise AP)</Radio>
        <Radio value={2}>整合制造系统(CIM)</Radio>
        <Radio value={3}>电脑系统(OA/IIT/AP)</Radio>
         </Radio.Group>
         </div>
         <div>&emsp;</div>
         {/* <div>添加附件：&emsp; */}
            <UploadFile />
         {/* </div> */}
         <div>&emsp;</div>
         <div>描述说明：&emsp;
             <TextArea
             style={{width:500}}
             onChange={this.showdata}
             />
         </div>
         <div>&emsp;</div>
         <div><span>申请人资讯：&emsp;</span>
         <span
         >
          <AddPerson
          />
          <Button style={{position:'relative',float:'right',left:'260px'}} >批量上传模板下载</Button>
            <Button style={{position:'relative',float:'right',left:'500px'}}>批量上传</Button>
          </span>
         </div>
         <div>&emsp;&emsp;&emsp;</div>
         <div>&emsp;&emsp;&emsp;</div>
         <div>&emsp;&emsp;&emsp;</div>
         <div>
          <ShowPersonData
          />
        </div>
         </Card>
           </Fragment>
        )
    }
}
const mapStateToProps=(state)=>{
     const {userid,name}=state.FillFormReducer.FillFormDetailReducer;
     return {userid,name}
}

const mapDispatchToProps=(dispatch)=>{
  return{
    getPersonDetail(){
        dispatch(actionCreators.getPersonDetail())
    }
  }
}


export default Form.create()(connect(mapStateToProps,mapDispatchToProps)(CommitForm));



