import React ,{Fragment,Component} from 'react';
import  { Upload,Input,Button, Form } from 'antd';

class UploadFile extends Component {


    state = {
        fileList: [
        ],
    };
    // fileList = fileList.slice(-2);
    handleChange = info => {
      let fileList = [...info.fileList];
  
      // 1. Limit the number of uploaded files
      // Only to show two recent uploaded files, and old ones will be replaced by the new
      fileList = fileList.slice(-1);
  
      // 2. Read from response and show file link
      fileList = fileList.map(file => {
        if (file.response) {
          // Component will show file.url as link
          file.url = file.response.url;
        }
        return file;
      });
  
      this.setState({ fileList });
    };

    render(){
        const props = {
        action: '',
        onChange: this.handleChange,
        multiple: true,
      };
        return(
            <div>
                <span className='fontFamily'>添加附件 &nbsp;: &nbsp;&nbsp;&nbsp;&nbsp; </span>
                {/* <Input className='inputinsert' disabled allowClear/> */}
                <Upload {...props} fileList={this.state.fileList}>
                  <Button className='annexbtn' style={{marginLeft:'50px'}}>
                    Upload
                  </Button>
              </Upload>
                 
            </div>
        )
    
    }
}


export  default Form.create()(UploadFile)