import { combineReducers } from 'redux';
import {reducer as FillFormDetailReducer} from '../FillForm/store';



export default combineReducers({
    FillFormDetailReducer,

})
