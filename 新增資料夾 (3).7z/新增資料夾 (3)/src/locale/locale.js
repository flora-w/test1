
import en from './en-gb.json';
import zh from './zh-cn.json';

// import a from ''

const locales={
    'en-us':en,
    'zh-cn':zh,
}

export default locales