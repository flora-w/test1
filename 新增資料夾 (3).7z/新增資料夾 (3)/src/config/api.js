export const LOGIN = '/Login/UserLogin'; //员工登陆
// export const LOGIN_TRALVEL = '/Login/UserLogin'; //员工登陆 

export const WAIT_FOR_SIGN_SUBMIT = '/Sign/Sign_Submit '; //提交签核
export const DELETE_CONTACTS = '/maintain/Linkman_Delete'; //删除目前个人代理设定信息
export const PUBLISHING_SEARCH_PAGE_INFO= 'Info/Info_Query';
export const SING_LIST='/'