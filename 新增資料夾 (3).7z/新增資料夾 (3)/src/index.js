import 'core-js/stable';
import 'regenerator-runtime/runtime';
import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { Provider } from 'react-redux';
import store from './store';
import RouterConfig from './routerConfig';
import * as serviceWorker from './serviceWorker';
import 'babel-polyfill';

import enUS from 'antd/es/locale/en_US';
import enGB from 'antd/es/locale/en_GB';
import zhCN from 'antd/es/locale/zh_CN';
import { ConfigProvider } from 'antd';
import 'moment/locale/zh-cn';

import intl from 'react-intl-universal';


import en from './locale/en-gb.json'
import zh from './locale/zh-cn.json';

// let lang = (navigator.languages && navigator.languages[0]) || navigator.language
// console.log(lang)
const locales={
    'en1':en,
    'zh1':zh,
  }
let lang =JSON.parse(sessionStorage.getItem('locale'));
let locale =lang?lang:zhCN;
console.log(lang)
console.log('12333333333333333')

  intl.init({
        // currentLocale:e.target.value=enGB?enGB:zhCN,
        // currentLocale:locales.zh1,
        currentLocale:enUS,
        locales
      }).then(()=>{
        // this.setState({ locale: e.target.value });
        // sessionStorage.setItem('locale',JSON.stringify(e.target.value ));
      })
  console.log(intl)    
 console.log(JSON.stringify(intl.get('key')) )
const App = (
       <ConfigProvider locale={locale} >
        <Provider store={store}>
            <RouterConfig
             key={locale ? locale.locale : 'en' /* Have to refresh for production environment */}
            />
        </Provider>
        </ConfigProvider>
        );

ReactDOM.render(App, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();


