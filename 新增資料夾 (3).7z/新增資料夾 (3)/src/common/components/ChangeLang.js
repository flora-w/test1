import React,{Component} from 'react';
import AgentSet from '../../pages/agentSetting/agentSet';
import SysAdmin from '../../pages/systemSetting/SysAdmin';
import SearchSpecialPerson from '../../pages/systemSetting/SearchSpecialPerson';
import AddSpecialPerson from '../../pages/systemSetting/AddSpecialPerson';

// import locales from '../../locale/locale';
import intl from 'react-intl-universal';
import {
    ConfigProvider,
    Button,
    Select,
    Radio,
  } from 'antd';
  import enUS from 'antd/es/locale/en_US';
  import zhCN from 'antd/es/locale/zh_CN';
  import enGB from 'antd/es/locale/en_GB';
  import moment from 'moment';
  import 'moment/locale/zh-cn';

import en from '../../locale/en-gb.json'
import zh from '../../locale/zh-cn.json';



  const { Option } = Select;
  moment.locale('en');

  const locales={
    'en1':en,
    'zh1':zh,
  }

class ChangeLang extends Component{

    constructor() {
        super();
        this.state = {
          locale: enUS,
        };
      }

    changeLocale = e => {
        const localeValue = e.target.value;
        this.setState({ locale: localeValue });
        // sessionStorage.setItem('intl',JSON.stringify(intl));
        sessionStorage.setItem('locale',JSON.stringify(e.target.value));
        window.location.reload(true);


        // console.log(e.target.value);

        if (!e.target.value ) {
          moment.locale('en');
        } else {
          moment.locale('zh-cn');
        }

      };

    render(){

        const { locale } = this.state;

        return(
            <div>
        <div className="change-locale">
          <span style={{ marginRight: 16 }}>切换语言 </span>
          <Radio.Group value={locale} onChange={this.changeLocale}>
            <Radio.Button key="en" value={enGB}>
              English
            </Radio.Button>
            <Radio.Button key="cn" value={zhCN}>
              中文
            </Radio.Button>
          </Radio.Group>
        </div>
        <ConfigProvider locale={locale}>
        {/* <SysAdmin
        //  key={locale ? locale.locale : 'en' /* Have to refresh for production environment*/}
        />  */}
        {/* <AddSpecialPerson/> */}
        </ConfigProvider>
      </div>

        )
    }
}

export default ChangeLang;